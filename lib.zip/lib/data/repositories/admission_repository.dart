import 'package:flutter/material.dart';

// lib/data/repositories/admission_repository.dart
// Auto-generated file

