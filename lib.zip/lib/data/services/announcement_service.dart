// lib/data/services/announcement_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/announcement_model.dart';
import 'api_service.dart';


class AnnouncementService {
  final ApiService _apiService;
  final String baseUrl;

  AnnouncementService({ApiService? apiService})
      : _apiService = apiService ?? ApiService(),
        baseUrl = ApiService.baseUrl;

  // Create announcement (Admin/Teacher)
  Future<Map<String, dynamic>> createAnnouncement({
    required String title,
    required String message,
    required String type,
    required String priority,
    required List<String> targetAudience,
    List<String>? targetClasses,
    List<String>? targetStudents,
    DateTime? expiryDate,
    String? attachmentUrl,
    String? attachmentName,
  }) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.post(
        Uri.parse('$baseUrl/announcements'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'title': title,
          'message': message,
          'type': type,
          'priority': priority,
          'target_audience': targetAudience,
          'target_classes': targetClasses,
          'target_students': targetStudents,
          'expiry_date': expiryDate?.toIso8601String(),
          'attachment_url': attachmentUrl,
          'attachment_name': attachmentName,
        }),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': 'Announcement created successfully',
          'data': data,
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to create announcement',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
      };
    }
  }

  // Get announcements for user
  Future<Map<String, dynamic>> getAnnouncements({
    String? userRole,
    String? userId,
    bool activeOnly = true,
    int page = 1,
    int limit = 20,
  }) async {
    try {
      final token = await _apiService.getToken();

      final queryParams = {
        'user_role': userRole,
        'user_id': userId,
        'active_only': activeOnly.toString(),
        'page': page.toString(),
        'limit': limit.toString(),
      };

      final uri = Uri.parse('$baseUrl/announcements')
          .replace(queryParameters: queryParams);

      final response = await http.get(
        uri,
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final announcements = (data['announcements'] as List)
            .map((json) => AnnouncementModel.fromJson(json))
            .toList();

        return {
          'success': true,
          'announcements': announcements,
          'total': data['total'] ?? announcements.length,
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to fetch announcements',
          'announcements': <AnnouncementModel>[],
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
        'announcements': <AnnouncementModel>[],
      };
    }
  }

  // Get announcement by ID
  Future<Map<String, dynamic>> getAnnouncementById(String id) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.get(
        Uri.parse('$baseUrl/announcements/$id'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final announcement = AnnouncementModel.fromJson(data);

        return {
          'success': true,
          'announcement': announcement,
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to fetch announcement',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
      };
    }
  }

  // Mark announcement as read
  Future<Map<String, dynamic>> markAsRead(String announcementId, String userId) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.post(
        Uri.parse('$baseUrl/announcements/$announcementId/read'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'user_id': userId,
        }),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': 'Marked as read',
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to mark as read',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
      };
    }
  }

  // Update announcement
  Future<Map<String, dynamic>> updateAnnouncement({
    required String id,
    String? title,
    String? message,
    String? type,
    String? priority,
    List<String>? targetAudience,
    List<String>? targetClasses,
    DateTime? expiryDate,
    bool? isActive,
  }) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.put(
        Uri.parse('$baseUrl/announcements/$id'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'title': title,
          'message': message,
          'type': type,
          'priority': priority,
          'target_audience': targetAudience,
          'target_classes': targetClasses,
          'expiry_date': expiryDate?.toIso8601String(),
          'is_active': isActive,
        }),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': 'Announcement updated successfully',
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to update announcement',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
      };
    }
  }

  // Delete announcement
  Future<Map<String, dynamic>> deleteAnnouncement(String id) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.delete(
        Uri.parse('$baseUrl/announcements/$id'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': 'Announcement deleted successfully',
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to delete announcement',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
      };
    }
  }

  // Get announcements by type
  Future<Map<String, dynamic>> getAnnouncementsByType(String type) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.get(
        Uri.parse('$baseUrl/announcements/type/$type'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final announcements = (data['announcements'] as List)
            .map((json) => AnnouncementModel.fromJson(json))
            .toList();

        return {
          'success': true,
          'announcements': announcements,
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to fetch announcements',
          'announcements': <AnnouncementModel>[],
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: ${e.toString()}',
        'announcements': <AnnouncementModel>[],
      };
    }
  }

  // Get unread announcements count
  Future<Map<String, dynamic>> getUnreadCount(String userId) async {
    try {
      final token = await _apiService.getToken();

      final response = await http.get(
        Uri.parse('$baseUrl/announcements/unread/count?user_id=$userId'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'count': data['count'] ?? 0,
        };
      } else {
        return {
          'success': false,
          'count': 0,
        };
      }
    } catch (e) {
      return {
        'success': false,
        'count': 0,
      };
    }
  }
}