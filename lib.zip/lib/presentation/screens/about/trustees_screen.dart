import 'package:flutter/material.dart';

// lib/presentation/screens/about/trustees_screen.dart
// Auto-generated file

