import 'package:flutter/material.dart';

// lib/data/models/faculty_model.dart
// Auto-generated file

