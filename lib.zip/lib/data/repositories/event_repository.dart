import 'package:flutter/material.dart';

// lib/data/repositories/event_repository.dart
// Auto-generated file

