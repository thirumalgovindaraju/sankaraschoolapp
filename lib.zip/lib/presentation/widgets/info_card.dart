import 'package:flutter/material.dart';

// lib/presentation/widgets/info_card.dart
// Auto-generated file

