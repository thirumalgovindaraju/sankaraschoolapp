import 'package:flutter/material.dart';

// lib/presentation/screens/curriculum/curriculum_screen.dart
// Auto-generated file

