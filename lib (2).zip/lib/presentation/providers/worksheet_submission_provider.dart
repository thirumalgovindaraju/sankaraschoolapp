// lib/presentation/providers/worksheet_submission_provider.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import '../../data/models/worksheet_generator_model.dart';

class WorksheetSubmissionProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  List<StudentSubmissionModel> _submissions = [];
  List<StudentSubmissionModel> _mySubmissions = [];
  bool _isLoading = false;
  String? _error;

  List<StudentSubmissionModel> get submissions => _submissions;
  List<StudentSubmissionModel> get mySubmissions => _mySubmissions;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Upload image to Firebase Storage
  Future<String?> uploadImage(File imageFile) async {
    try {
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'worksheet_images/$timestamp.jpg';

      final ref = _storage.ref().child(fileName);
      await ref.putFile(imageFile);

      final downloadUrl = await ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print('❌ Error uploading image: $e');
      _error = 'Failed to upload image: $e';
      notifyListeners();
      return null;
    }
  }

  /// Submit worksheet
  Future<bool> submitWorksheet(StudentSubmissionModel submission) async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      await _firestore
          .collection('worksheet_submissions')
          .doc(submission.id)
          .set(submission.toMap());

      print('✅ Worksheet submitted: ${submission.id}');

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print('❌ Error submitting worksheet: $e');
      _error = 'Failed to submit: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Fetch student's own submissions
  Future<void> fetchMySubmissions(String studentId) async {
    try {
      _isLoading = true;
      notifyListeners();

      final snapshot = await _firestore
          .collection('worksheet_submissions')
          .where('studentId', isEqualTo: studentId)
          .orderBy('submittedAt', descending: true)
          .get();

      _mySubmissions = snapshot.docs
          .map((doc) => StudentSubmissionModel.fromMap(doc.data()))
          .toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print('❌ Error fetching submissions: $e');
      _error = 'Failed to fetch submissions: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Fetch all submissions for a worksheet (Teacher view)
  Future<void> fetchWorksheetSubmissions(String worksheetId) async {
    try {
      _isLoading = true;
      notifyListeners();

      final snapshot = await _firestore
          .collection('worksheet_submissions')
          .where('worksheetId', isEqualTo: worksheetId)
          .orderBy('submittedAt', descending: true)
          .get();

      _submissions = snapshot.docs
          .map((doc) => StudentSubmissionModel.fromMap(doc.data()))
          .toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print('❌ Error fetching submissions: $e');
      _error = 'Failed to fetch submissions: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Grade a submission (Teacher)
  Future<bool> gradeSubmission({
    required String submissionId,
    required List<StudentAnswer> gradedAnswers,
    required int totalMarksAwarded,
    required String teacherFeedback,
    required String gradedBy,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      final percentage = (totalMarksAwarded /
          (gradedAnswers.fold<int>(0, (sum, a) => sum + (a.marksAwarded ?? 0)))) * 100;

      String grade = 'F';
      if (percentage >= 90) grade = 'A*';
      else if (percentage >= 80) grade = 'A';
      else if (percentage >= 70) grade = 'B';
      else if (percentage >= 60) grade = 'C';
      else if (percentage >= 50) grade = 'D';
      else if (percentage >= 40) grade = 'E';

      await _firestore
          .collection('worksheet_submissions')
          .doc(submissionId)
          .update({
        'answers': gradedAnswers.map((a) => a.toMap()).toList(),
        'marksObtained': totalMarksAwarded,
        'teacherFeedback': teacherFeedback,
        'gradedAt': DateTime.now(),
        'gradedBy': gradedBy,
        'status': SubmissionStatus.graded.toString(),
        'percentage': percentage,
        'grade': grade,
      });

      print('✅ Submission graded: $submissionId');

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print('❌ Error grading submission: $e');
      _error = 'Failed to grade: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Auto-grade MCQ questions
  void autoGradeMCQs(
      StudentSubmissionModel submission,
      List<QuestionModel> questions,
      ) {
    for (var answer in submission.answers) {
      final question = questions.firstWhere(
            (q) => q.id == answer.questionId,
        orElse: () => questions.first,
      );

      if (question.type == QuestionType.mcq) {
        final isCorrect = answer.answer == question.correctAnswer;
        answer = StudentAnswer(
          questionId: answer.questionId,
          questionNumber: answer.questionNumber,
          answer: answer.answer,
          attachmentUrls: answer.attachmentUrls,
          marksAwarded: isCorrect ? question.marks : 0,
          isCorrect: isCorrect,
          feedback: isCorrect ? 'Correct!' : 'Incorrect. Correct answer: ${question.correctAnswer}',
        );
      }
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}