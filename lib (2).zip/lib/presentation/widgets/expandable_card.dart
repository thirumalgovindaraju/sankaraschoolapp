import 'package:flutter/material.dart';

// lib/presentation/widgets/expandable_card.dart
// Auto-generated file

