// lib/data/services/pdf_processor_service.dart
// ✅ FIXED - Handles Windows Firebase Storage issue

import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/worksheet_generator_model.dart';

class PDFProcessorService {
  static final FirebaseStorage _storage = FirebaseStorage.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Upload textbook PDF
  static Future<TextbookModel?> uploadTextbook({
    required String title,
    required String subject,
    required String board,
    required String grade,
    required String uploadedBy,
    String? publisher,
    String? edition,
    int? totalPages,
  }) async {
    try {
      print('📚 Starting textbook upload...');

      // Step 1: Pick PDF file
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        withData: true,
      );

      if (result == null) {
        print('❌ No file selected');
        return null;
      }

      final file = result.files.first;
      print('✅ File selected: ${file.name} (${file.size} bytes)');

      if (file.size > 100 * 1024 * 1024) {
        throw Exception('File too large. Maximum size is 100MB');
      }

      // Step 2: Generate unique filename
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final textbookId = 'textbook_$timestamp';
      final sanitizedFileName = file.name.replaceAll(' ', '_');
      final fileName = '${textbookId}_$sanitizedFileName';
      final storagePath = 'textbooks/$fileName';

      print('📤 Uploading to: $storagePath');

      // Step 3: Upload to Firebase Storage
      final storageRef = _storage.ref().child(storagePath);

      final metadata = SettableMetadata(
        contentType: 'application/pdf',
        customMetadata: {
          'uploadedBy': uploadedBy,
          'subject': subject,
          'textbookId': textbookId,
        },
      );

      UploadTask uploadTask;

      if (file.bytes != null) {
        print('📱 Uploading from bytes...');
        uploadTask = storageRef.putData(file.bytes!, metadata);
      } else if (file.path != null) {
        print('💻 Uploading from file path...');
        uploadTask = storageRef.putFile(File(file.path!), metadata);
      } else {
        throw Exception('Cannot read file data');
      }

      // Monitor progress
      uploadTask.snapshotEvents.listen((event) {
        final progress = (event.bytesTransferred / event.totalBytes) * 100;
        print('📊 Upload progress: ${progress.toStringAsFixed(1)}%');
      });

      // Wait for upload to complete
      print('⏳ Waiting for upload to complete...');
      final snapshot = await uploadTask.whenComplete(() => null);

      print('✅ Upload complete!');
      print('📦 State: ${snapshot.state}');
      print('📦 Bytes: ${snapshot.bytesTransferred}/${snapshot.totalBytes}');

      // ✅ CRITICAL FIX: Check upload state before getting URL
      if (snapshot.state != TaskState.success) {
        throw Exception('Upload did not complete successfully. State: ${snapshot.state}');
      }

      // Add delay to ensure file is fully written
      print('⏳ Waiting for file to be fully written...');
      await Future.delayed(const Duration(seconds: 2));

      // Get download URL with multiple retry attempts
      String? pdfUrl;
      int maxRetries = 5;

      for (int attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          print('🔗 Attempt $attempt/$maxRetries: Getting download URL...');

          // Try getting URL from completed snapshot
          pdfUrl = await snapshot.ref.getDownloadURL();
          print('✅ Download URL obtained: $pdfUrl');
          break;

        } catch (e) {
          print('⚠️ Attempt $attempt failed: $e');

          if (attempt < maxRetries) {
            // Wait progressively longer between retries
            final waitSeconds = attempt * 2;
            print('⏳ Waiting ${waitSeconds}s before retry...');
            await Future.delayed(Duration(seconds: waitSeconds));

            // Try with a fresh reference
            try {
              final freshRef = _storage.ref().child(storagePath);
              pdfUrl = await freshRef.getDownloadURL();
              print('✅ Got URL from fresh reference: $pdfUrl');
              break;
            } catch (freshError) {
              print('⚠️ Fresh reference also failed: $freshError');
            }
          } else {
            // Last attempt failed - check if file exists
            print('❌ All retry attempts exhausted');
            print('🔍 Checking if file exists in Storage...');

            try {
              final listResult = await _storage.ref('textbooks').listAll();
              print('📂 Files in textbooks folder:');
              for (var item in listResult.items) {
                print('  - ${item.name}');
              }
            } catch (listError) {
              print('⚠️ Could not list files: $listError');
            }

            throw Exception(
                'Failed to get download URL after $maxRetries attempts. '
                    'The file may not have been saved to Firebase Storage. '
                    'Check your Firebase Storage rules and ensure they allow authenticated reads/writes.'
            );
          }
        }
      }

      if (pdfUrl == null) {
        throw Exception('Failed to obtain download URL');
      }

      print('🎉 File successfully uploaded and accessible!');

      // Step 4: Create textbook model
      final textbook = TextbookModel(
        id: textbookId,
        title: title,
        subject: subject,
        board: board,
        grade: grade,
        pdfUrl: pdfUrl,
        chapters: _createSampleChapters(subject),
        uploadedAt: DateTime.now(),
        uploadedBy: uploadedBy,
        totalPages: totalPages ?? 200,
        publisher: publisher,
        edition: edition,
        processingStatus: ProcessingStatus.completed,
      );

      // Step 5: Save to Firestore
      print('💾 Saving textbook metadata to Firestore...');
      await _firestore
          .collection('textbooks')
          .doc(textbookId)
          .set(textbook.toMap());

      print('✅ Textbook saved successfully!');
      print('📚 ID: $textbookId');
      print('📖 Chapters: ${textbook.chapters.length}');

      return textbook;

    } on FirebaseException catch (e) {
      print('❌ Firebase Error: ${e.code}');
      print('📝 Message: ${e.message}');
      print('📍 Plugin: ${e.plugin}');

      if (e.code == 'object-not-found') {
        print('');
        print('🔧 TROUBLESHOOTING STEPS:');
        print('1. Check Firebase Storage Rules in Firebase Console');
        print('2. Ensure rules allow: allow read, write: if request.auth != null;');
        print('3. Make sure user is authenticated');
        print('4. Verify Storage bucket exists');
        print('');
      }

      return null;

    } catch (e, stackTrace) {
      print('❌ Error uploading textbook: $e');
      print('📋 Stack trace: $stackTrace');
      return null;
    }
  }

  /// Create sample chapters based on subject
  static List<ChapterModel> _createSampleChapters(String subject) {
    if (subject.toLowerCase() == 'mathematics') {
      return [
        ChapterModel(
          id: 'ch1',
          title: 'Number Systems',
          chapterNumber: 1,
          startPage: 1,
          endPage: 25,
          extractedText: 'Content about number systems.',
          topics: [
            TopicModel(
              id: 'topic_1_1',
              name: 'Integers and Rational Numbers',
              description: 'Understanding integers and rational numbers',
              keywords: ['integers', 'rational', 'numbers'],
              formulas: [],
              difficulty: DifficultyLevel.easy,
              pageReference: 5,
              learningObjectives: ['Understand integers', 'Work with rational numbers'],
            ),
            TopicModel(
              id: 'topic_1_2',
              name: 'Real Numbers',
              description: 'Properties of real numbers',
              keywords: ['real', 'irrational', 'numbers'],
              formulas: [],
              difficulty: DifficultyLevel.medium,
              pageReference: 15,
              learningObjectives: ['Identify real numbers', 'Perform operations'],
            ),
          ],
        ),
        ChapterModel(
          id: 'ch2',
          title: 'Algebra',
          chapterNumber: 2,
          startPage: 26,
          endPage: 75,
          extractedText: 'Algebraic concepts and equations.',
          topics: [
            TopicModel(
              id: 'topic_2_1',
              name: 'Linear Equations',
              description: 'Solving linear equations',
              keywords: ['linear', 'equations', 'variables'],
              formulas: ['ax + b = 0', 'y = mx + c'],
              difficulty: DifficultyLevel.medium,
              pageReference: 30,
              learningObjectives: ['Solve linear equations', 'Apply to problems'],
            ),
            TopicModel(
              id: 'topic_2_2',
              name: 'Quadratic Equations',
              description: 'Solving quadratic equations',
              keywords: ['quadratic', 'formula', 'roots'],
              formulas: ['ax² + bx + c = 0', 'x = (-b ± √(b²-4ac))/2a'],
              difficulty: DifficultyLevel.hard,
              pageReference: 50,
              learningObjectives: ['Use quadratic formula', 'Find roots'],
            ),
          ],
        ),
        ChapterModel(
          id: 'ch3',
          title: 'Geometry',
          chapterNumber: 3,
          startPage: 76,
          endPage: 120,
          extractedText: 'Geometric shapes and theorems.',
          topics: [
            TopicModel(
              id: 'topic_3_1',
              name: 'Triangles',
              description: 'Triangle properties and theorems',
              keywords: ['triangles', 'pythagoras', 'angles'],
              formulas: ['a² + b² = c²', 'Area = ½bh'],
              difficulty: DifficultyLevel.medium,
              pageReference: 80,
              learningObjectives: ['Apply Pythagorean theorem', 'Calculate areas'],
            ),
          ],
        ),
      ];
    }

    // Generic chapters for other subjects
    return [
      ChapterModel(
        id: 'ch1',
        title: 'Introduction',
        chapterNumber: 1,
        startPage: 1,
        endPage: 30,
        extractedText: 'Introduction chapter.',
        topics: [
          TopicModel(
            id: 'topic_1',
            name: 'Basic Concepts',
            description: 'Fundamental concepts',
            keywords: ['basics', 'introduction'],
            formulas: [],
            difficulty: DifficultyLevel.easy,
            pageReference: 5,
            learningObjectives: ['Understand basics'],
          ),
        ],
      ),
    ];
  }

  /// Get all textbooks
  static Future<List<TextbookModel>> getTextbooks() async {
    try {
      print('📚 Fetching textbooks from Firestore...');
      final snapshot = await _firestore
          .collection('textbooks')
          .orderBy('uploadedAt', descending: true)
          .get();

      final textbooks = snapshot.docs
          .map((doc) => TextbookModel.fromMap(doc.data()))
          .toList();

      print('✅ Fetched ${textbooks.length} textbooks');
      return textbooks;
    } catch (e) {
      print('❌ Error fetching textbooks: $e');
      return [];
    }
  }

  /// Get textbook by ID
  static Future<TextbookModel?> getTextbookById(String id) async {
    try {
      final doc = await _firestore.collection('textbooks').doc(id).get();
      if (doc.exists) {
        return TextbookModel.fromMap(doc.data()!);
      }
      return null;
    } catch (e) {
      print('❌ Error fetching textbook: $e');
      return null;
    }
  }

  /// Delete textbook
  static Future<bool> deleteTextbook(String id) async {
    try {
      final textbook = await getTextbookById(id);
      if (textbook == null) return false;

      // Delete from Storage
      try {
        final ref = _storage.refFromURL(textbook.pdfUrl);
        await ref.delete();
        print('✅ File deleted from Storage');
      } catch (e) {
        print('⚠️ Could not delete file from Storage: $e');
      }

      // Delete from Firestore
      await _firestore.collection('textbooks').doc(id).delete();
      print('✅ Textbook deleted from Firestore');

      return true;
    } catch (e) {
      print('❌ Error deleting textbook: $e');
      return false;
    }
  }
}