// lib/data/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Static base URL - Update this to your actual API URL
  static const String baseUrl = 'https://your-api-url.com/api';

  // Singleton pattern
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // Authorization token
  String? _authToken;

  // Set auth token
  void setAuthToken(String token) {
    _authToken = token;
  }

  // Get token from shared preferences
  Future<String?> getToken() async {
    try {
      if (_authToken != null) return _authToken;

      final prefs = await SharedPreferences.getInstance();
      _authToken = prefs.getString('auth_token');
      return _authToken;
    } catch (e) {
      print('Error getting token: $e');
      return null;
    }
  }

  // Save token
  Future<bool> saveToken(String token) async {
    try {
      _authToken = token;
      final prefs = await SharedPreferences.getInstance();
      return await prefs.setString('auth_token', token);
    } catch (e) {
      print('Error saving token: $e');
      return false;
    }
  }

  // Remove token
  Future<bool> removeToken() async {
    try {
      _authToken = null;
      final prefs = await SharedPreferences.getInstance();
      return await prefs.remove('auth_token');
    } catch (e) {
      print('Error removing token: $e');
      return false;
    }
  }

  // Check if user is authenticated
  Future<bool> isAuthenticated() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }

  // Get headers with auth token
  Future<Map<String, String>> getHeaders() async {
    final token = await getToken();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // Get auth headers (without content-type)
  Future<Map<String, String>> getAuthHeaders() async {
    final token = await getToken();
    return {
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // Helper to build URL with query parameters
  Uri _buildUri(String endpoint, {Map<String, dynamic>? queryParameters}) {
    final uri = Uri.parse('$baseUrl$endpoint');

    if (queryParameters != null && queryParameters.isNotEmpty) {
      return uri.replace(
        queryParameters: queryParameters.map(
              (key, value) => MapEntry(key, value.toString()),
        ),
      );
    }

    return uri;
  }

  // GET request with optional query parameters
  Future<http.Response> get(
      String endpoint, {
        Map<String, dynamic>? queryParameters,
      }) async {
    final url = _buildUri(endpoint, queryParameters: queryParameters);
    final headers = await getHeaders();
    return await http.get(url, headers: headers);
  }

  // POST request
  Future<http.Response> post(String endpoint, Map<String, dynamic> body) async {
    final url = Uri.parse('$baseUrl$endpoint');
    final headers = await getHeaders();
    return await http.post(
      url,
      headers: headers,
      body: json.encode(body),
    );
  }

  // PUT request
  Future<http.Response> put(String endpoint, Map<String, dynamic> body) async {
    final url = Uri.parse('$baseUrl$endpoint');
    final headers = await getHeaders();
    return await http.put(
      url,
      headers: headers,
      body: json.encode(body),
    );
  }

  // PATCH request
  Future<http.Response> patch(String endpoint, Map<String, dynamic> body) async {
    final url = Uri.parse('$baseUrl$endpoint');
    final headers = await getHeaders();
    return await http.patch(
      url,
      headers: headers,
      body: json.encode(body),
    );
  }

  // DELETE request
  Future<http.Response> delete(String endpoint) async {
    final url = Uri.parse('$baseUrl$endpoint');
    final headers = await getHeaders();
    return await http.delete(url, headers: headers);
  }

  // ==================== CONVENIENCE METHODS ====================

  // Generic GET with auto JSON parsing
  Future<Map<String, dynamic>> getJson(
      String endpoint, {
        Map<String, dynamic>? queryParameters,
      }) async {
    try {
      final response = await get(endpoint, queryParameters: queryParameters);

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {
          'success': false,
          'message': 'Request failed with status: ${response.statusCode}',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: $e',
      };
    }
  }

  // Generic POST with auto JSON parsing
  Future<Map<String, dynamic>> postJson(
      String endpoint,
      Map<String, dynamic> body,
      ) async {
    try {
      final response = await post(endpoint, body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        return {
          'success': false,
          'message': 'Request failed with status: ${response.statusCode}',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error: $e',
      };
    }
  }

  // ==================== EXISTING METHODS ====================

  // Get events
  Future<List<dynamic>> getEvents() async {
    try {
      final response = await get('/events');
      if (response.statusCode == 200) {
        return json.decode(response.body)['data'] ?? [];
      }
      return [];
    } catch (e) {
      print('Error fetching events: $e');
      return [];
    }
  }

  // Submit admission
  Future<void> submitAdmission(Map<String, dynamic> data) async {
    try {
      await post('/admissions', data);
    } catch (e) {
      print('Error submitting admission: $e');
      rethrow;
    }
  }
}