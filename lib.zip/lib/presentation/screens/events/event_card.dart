import 'package:flutter/material.dart';

// lib/presentation/screens/events/event_card.dart
// Auto-generated file

