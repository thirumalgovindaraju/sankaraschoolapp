import 'package:flutter/material.dart';

// lib/presentation/screens/curriculum/program_details_screen.dart
// Auto-generated file

