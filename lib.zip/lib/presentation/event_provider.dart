import 'package:flutter/material.dart';

// lib/presentation/event_provider.dart
// Auto-generated file

