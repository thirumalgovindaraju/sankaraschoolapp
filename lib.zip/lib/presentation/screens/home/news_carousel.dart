import 'package:flutter/material.dart';

// lib/presentation/screens/home/news_carousel.dart
// Auto-generated file

