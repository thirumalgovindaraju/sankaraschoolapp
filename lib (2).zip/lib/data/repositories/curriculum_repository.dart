import 'package:flutter/material.dart';

// lib/data/repositories/curriculum_repository.dart
// Auto-generated file

