import 'package:flutter/material.dart';

// lib/presentation/screens/events/event_details_screen.dart
// Auto-generated file

