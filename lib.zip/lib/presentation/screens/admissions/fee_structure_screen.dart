import 'package:flutter/material.dart';

// lib/presentation/screens/admissions/fee_structure_screen.dart
// Auto-generated file

