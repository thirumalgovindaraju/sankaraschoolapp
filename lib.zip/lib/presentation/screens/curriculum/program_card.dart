import 'package:flutter/material.dart';

// lib/presentation/screens/curriculum/program_card.dart
// Auto-generated file

