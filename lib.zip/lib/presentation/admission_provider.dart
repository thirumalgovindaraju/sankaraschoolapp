import 'package:flutter/material.dart';

// lib/presentation/admission_provider.dart
// Auto-generated file

