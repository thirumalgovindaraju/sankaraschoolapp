import 'package:flutter/material.dart';

// lib/presentation/curriculum_provider.dart
// Auto-generated file

