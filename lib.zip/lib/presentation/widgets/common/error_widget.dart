import 'package:flutter/material.dart';

// lib/presentation/widgets/common/error_widget.dart
// Auto-generated file

