import 'package:flutter/material.dart';

// lib/presentation/screens/admissions/admissions_screen.dart
// Auto-generated file

