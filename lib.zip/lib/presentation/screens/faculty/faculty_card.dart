import 'package:flutter/material.dart';

// lib/presentation/screens/faculty/faculty_card.dart
// Auto-generated file

