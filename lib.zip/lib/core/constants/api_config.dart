// lib/core/constants/api_config.dart
class ApiConfig {
  static const String baseUrl = 'https://your-api-url.com/api';
  static const bool useMockData = true; // Set to false when using real backend
}