import 'package:flutter/material.dart';

// lib/data/repositories/faculty_repository.dart
// Auto-generated file

